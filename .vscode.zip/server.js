require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || 'blood_bank',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

app.post('/api/donors/register', async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      email,
      phone,
      bloodGroup,
      gender,
      dateOfBirth,
      address,
    } = req.body;

    if (!email || !firstName || !lastName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const existing = await pool.query('SELECT donor_id FROM "Donor" WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Email already exists' });
    }

    const dateOfBirthParam = dateOfBirth ? `{${dateOfBirth}}` : null;
    const addressParam = address ? `{${address.replace(/\"/g, '\\"')}}` : null;

    const insertSql = `
      INSERT INTO "Donor"
      (first_name, last_name, email, phone, blood_group, gender, date_of_birth, address, eligibility_status)
      VALUES ($1,$2,$3,$4,$5,$6,$7::date[], $8::text[], $9)
      RETURNING donor_id, first_name, last_name, email, blood_group;
    `;

    const result = await pool.query(insertSql, [
      firstName,
      lastName,
      email,
      phone,
      bloodGroup,
      gender || null,
      dateOfBirthParam,
      addressParam,
      'eligible',
    ]);

    res.status(201).json({ donor: result.rows[0] });
  } catch (err) {
    console.error('Error /api/donors/register', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/donors/login', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email required' });
    }

    const q = `SELECT donor_id, first_name, last_name, email, blood_group FROM "Donor" WHERE email = $1`;
    const result = await pool.query(q, [email]);

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Donor not found' });
    }

    res.json({ donor: result.rows[0] });
  } catch (err) {
    console.error('Error /api/donors/login', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/donors/info', async (req, res) => {
  try {
    const { email, first_name, last_name, blood_group, phone, gender, dateOfBirth, address } = req.body;

    if (!email || !first_name || !last_name) {
      return res.status(400).json({ error: 'Missing donor info fields' });
    }

    const dateOfBirthParam = dateOfBirth ? `{${dateOfBirth}}` : null;
    const addressParam = address ? `{${address.replace(/\"/g, '\\"')}}` : null;

    const sql = `
      UPDATE "Donor"
      SET first_name = $1, last_name = $2, blood_group = $3, phone = $4, gender = $5, date_of_birth = $6::date[], address = $7::text[]
      WHERE email = $8
      RETURNING *;
    `;

    const result = await pool.query(sql, [
      first_name,
      last_name,
      blood_group,
      phone,
      gender || null,
      dateOfBirthParam,
      addressParam,
      email,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Donor not found, please login first' });
    }

    res.status(200).json({ donorInfo: result.rows[0] });
  } catch (err) {
    console.error('Error /api/donors/info', err);
    res.status(500).json({ error: 'Saving donor info failed' });
  }
});

// ============ BLOOD UNIT / INVENTORY ============
app.get('/api/inventory', async (req, res) => {
  try {
    const q = `SELECT * FROM "BloodUnit" LIMIT 100`;
    const result = await pool.query(q);
    res.json(result.rows);
  } catch (err) {
    console.error('Error /api/inventory', err);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// ============ HOSPITAL (REQUEST) ============
app.post('/api/hospitals/register', async (req, res) => {
  try {
    const { hospitalName, contactPerson, phone, email, address } = req.body;

    if (!email || !hospitalName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const existing = await pool.query('SELECT hospital_id FROM "Hospital" WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const sql = `
      INSERT INTO "Hospital" (hospital_name, contact_person, phone, email, address)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING hospital_id, hospital_name, email;
    `;

    const result = await pool.query(sql, [hospitalName, contactPerson || null, phone || null, email, address || null]);
    res.status(201).json({ hospital: result.rows[0] });
  } catch (err) {
    console.error('Error /api/hospitals/register', err);
    res.status(500).json({ error: 'Registration failed: ' + err.message });
  }
});

app.post('/api/hospitals/login', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email required' });
    }

    const q = `SELECT hospital_id, hospital_name, email FROM "Hospital" WHERE email = $1`;
    const result = await pool.query(q, [email]);

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Hospital not found' });
    }

    res.json({ hospital: result.rows[0] });
  } catch (err) {
    console.error('Error /api/hospitals/login', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/blood-requests', async (req, res) => {
  try {
    const { hospitalId, bloodGroup, componentType, quantity, urgency, reasonForRequest } = req.body;

    if (!hospitalId || !bloodGroup || !quantity || !componentType) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const parsedQuantity = parseInt(quantity, 10);
    if (Number.isNaN(parsedQuantity) || parsedQuantity <= 0) {
      return res.status(400).json({ error: 'Quantity must be a positive number' });
    }

    const sql = `
      INSERT INTO "BloodRequest" (hospital_id, blood_group, component_type, quantity_units, request_date, urgency_level, status)
      VALUES ($1,$2,$3,$4,CURRENT_DATE,$5,$6)
      RETURNING request_id, blood_group, component_type, quantity_units;
    `;

    const result = await pool.query(sql, [hospitalId, bloodGroup, componentType, parsedQuantity, urgency || 'Normal', 'Pending']);
    res.status(201).json({ request: result.rows[0] });
  } catch (err) {
    console.error('Error /api/blood-requests', err);
    res.status(500).json({ error: 'Request submission failed: ' + err.message });
  }
});

// ============ STAFF / COLLECTION CENTRE ============
app.post('/api/staff/register', async (req, res) => {
  try {
    const { centreName, licenseNo, email, password, contactPerson, phone, city, address } = req.body;

    if (!email || !centreName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const existing = await pool.query('SELECT staff_id FROM "Staff" WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    // Map frontend fields to the actual Staff table columns
    const sql = `
      INSERT INTO "Staff" (first_name, last_name, role, phone, email, shift_timing)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING staff_id, first_name, last_name, email;
    `;

    const result = await pool.query(sql, [
      centreName,
      licenseNo || '',
      'collection_centre',
      phone,
      email,
      'Day'
    ]);

    res.status(201).json({ staff: result.rows[0] });
  } catch (err) {
    console.error('Error /api/staff/register', err);
    res.status(500).json({ error: 'Registration failed: ' + err.message });
  }
});

app.post('/api/staff/login', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email required' });
    }

    const q = `SELECT staff_id, (first_name || ' ' || last_name) as staff_name, email FROM "Staff" WHERE email = $1`;
    const result = await pool.query(q, [email]);

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Staff member not found' });
    }

    res.json({ staff: result.rows[0] });
  } catch (err) {
    console.error('Error /api/staff/login', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/blood-collection', async (req, res) => {
  try {
    const { staffId, bloodGroup, componentType, quantity, expiryDate } = req.body;

    if (!staffId || !bloodGroup || !quantity) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const sql = `
      INSERT INTO "BloodUnit" (blood_group, component_type, quantity, expiry_date, status)
      VALUES ($1,$2,$3,$4,$5)
      RETURNING unit_id, blood_group, quantity;
    `;

    const result = await pool.query(sql, [bloodGroup, componentType || 'Whole Blood', quantity, expiryDate || null, 'Available']);
    res.status(201).json({ bloodUnit: result.rows[0] });
  } catch (err) {
    console.error('Error /api/blood-collection', err);
    res.status(500).json({ error: 'Collection submission failed' });
  }
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});

// Catch-all 404 handler - must be last
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});
